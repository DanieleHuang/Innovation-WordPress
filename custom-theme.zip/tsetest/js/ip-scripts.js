console.log("Success!");
let displayedCategories = ["2","3","4"];
let categoryRef = ["uncat", "prof-dev", "cat-b", "cat-a"];
let currentType = "";

function ipResetUserType() {
	document.getElementById("user-type-display").innerHTML = "";
	document.getElementById("ip-student-type").classList.remove("selected");
	document.getElementById("ip-faculty-type").classList.remove("selected");
	document.getElementById("ip-alumni-type").classList.remove("selected");
	
	let topics = document.getElementsByClassName("ident-topic");
	let i;
	for (i = 0; i < topics.length; i++) {
		topics[i].classList.remove("ip-hidden");
	}
	
	let boxItems = document.getElementsByClassName("ip-cat");
	for (i = 0; i < boxItems.length; i++) {
		boxItems[i].classList.add("ip-hidden");
	}
	
	let boxes = document.getElementsByClassName("ip-cat-box");
	for (i = 0; i < boxes.length; i++) {
		boxes[i].checked = false;
	}
}

function ipUpdateUserType(type, currentId) {
	if (document.getElementById(currentId).classList.contains("selected")) {
		return;
	}
	
	ipResetUserType();
	document.getElementById("user-type-display").innerHTML = type;
	document.getElementById(currentId).classList.add("selected");
	
	let typeClass;
	if (type == "Student") {
		typeClass = "ip-st-cat";
		currentType = "st";
	} else if (type == "Faculty") {
		typeClass = "ip-fc-cat";
		currentType = "fc";
	} else {
		typeClass = "ip-al-cat";
		currentType = "al";
	}
	
	let catStuff = document.getElementsByClassName(typeClass);
	let i;
	for (i = 0; i < catStuff.length; i++) {
		catStuff[i].classList.remove("ip-hidden");
	}
	
	ipShowAllCategories();
	apiTest();
}

function ipShowAllCategories() {
	if ( currentType == "st" ) {
		displayedCategories = ["2"];
	} else if ( currentType == "fc" ) {
		displayedCategories = ["2", "3"];
	} else if ( currentType == "al" ) {
		displayedCategories = ["3", "4"];
	} else {
		displayedCategories = ["2","3","4"];
	}
}

function ipHideAllCategories() {
	displayedCategories = [];
}

function ipAllCatsShown() {
	return (displayedCategories.length == 1 && currentType == "st") ||
		(displayedCategories.length == 2 && (currentType == "fc" || currentType == "al")) ||
		(displayedCategories.length == 3 && currentType == "");
}

function ipAllCatsHidden() {
	return displayedCategories.length == 0;
}

function ipToggleCategory(category) {
	//console.log(displayedCategories);
	
	if (ipAllCatsShown() && 
	   document.getElementById("ip-" + categoryRef[parseInt(category) - 1] + "-box").checked) {
		ipHideAllCategories();
	}
	
	//console.log(displayedCategories);
	//console.log(category + " " + "ip-" + categoryRef[parseInt(category) - 1] + "-box");
	//console.log(document.getElementById("ip-" + categoryRef[parseInt(category) - 1] + 
	//									  "-box").checked);
	
	if ( ! document.getElementById("ip-" + categoryRef[parseInt(category) - 1] + "-box").checked) {
		displayedCategories = displayedCategories.filter(function remCat(cat) { 
			return cat != category;
		});
	} else { 
		displayedCategories.push(category);
	}
	
	//console.log(displayedCategories);
	
	if (ipAllCatsHidden() == true) {
		ipShowAllCategories();
	}
	
	//console.log(displayedCategories);
	
	apiTest();
}

function apiTest() {
	if (ipAllCatsHidden()) {
		document.getElementById("ip-resource-div").innerHTML = "";
		return;
	}
	
	let categories = displayedCategories[0];
	for (i = 1; i < displayedCategories.length; i++) {
		categories = categories + "," + displayedCategories[i];
	}
	
	let request = new XMLHttpRequest();
	request.onreadystatechange = function() {
		console.log(request.statusText);
    	if (this.readyState == 4 && this.status == 200) {
       		// Typical action to be performed when the document is ready:
       		console.log(categories);
			let posts = JSON.parse(request.responseText);
			
			let div = document.getElementById("ip-resource-div");
			let string = posts[0].title.rendered;
			for (i = 1; i < posts.length; i++) {
				string = string + "<br>" + posts[i].title.rendered;
			}
			div.innerHTML = string;
    	}
	};
	request.open("GET", "/tse-wordpress/wp-json/wp/v2/posts?categories=" + categories);
	request.send();
}